# Databricks notebook source
!pip install databricks-sdk

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from databricks.sdk import WorkspaceClient

host_name = "https://adb-4661267993302765.5.azuredatabricks.net"
# token = "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"
w = WorkspaceClient(host= host_name, token= token)

# COMMAND ----------

w.jobs.get_run("252723146360282")

# COMMAND ----------

# MAGIC %sh
# MAGIC curl --request GET "https://adb-4661267993302765.5.azuredatabricks.net/api/2.0/clusters/get" \
# MAGIC      --header "Authorization: Bearer dapi7fa5cd8bf308cb878839acc1986ac9fa-3" \
# MAGIC      --data '{ "cluster_id": "0222-132740-rfm3blyd" }'

# COMMAND ----------

# MAGIC %sh
# MAGIC curl --request GET "https://adb-4661267993302765.5.azuredatabricks.net/api/2.0/jobs/runs/get?run_id=252723146360282" \
# MAGIC      --header "Authorization: Bearer dapi7fa5cd8bf308cb878839acc1986ac9fa-3"

# COMMAND ----------

# MAGIC %sh
# MAGIC curl --request GET "https://adb-4661267993302765.5.azuredatabricks.net/api/2.0/jobs/runs/get?run_id=252723146360282" \
# MAGIC      --header "Authorization: Bearer dapi6fde62e4d8f93b609e2dcf54123f15c5-3"

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,not working
import requests
import json

# Your Databricks instance and token
databricks_url = "https://adb-4661267993302765.5.azuredatabricks.net/api/2.0/clusters/get"
# token = "dapi7fa5cd8bf308cb878839acc1986ac9fa-3"
# token = "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"

# The run ID of the job
run_id = "252723146360282"

job id (job run id)-> task -> duration
# Fetch job run details
response = requests.get(
    f"{databricks_url}/api/2.0/jobs/runs/get?run_id={run_id}",
    headers={"Authorization": f"Bearer {token}"}
)

run_details = response.json()

# Print the run details to understand its structure
print(json.dumps(run_details, indent=2))

# Loop through each task in the run details and capture duration
task_durations = []
if 'tasks' in run_details:
    for task in run_details['tasks']:
        task_name = task['task_key']
        start_time = task['start_time']
        end_time = task['end_time']
        duration = task['duration'] / 1000  # Convert duration from milliseconds to seconds

        task_durations.append({
            'task_name': task_name,
            'start_time': start_time,
            'end_time': end_time,
            'duration_seconds': duration
        })

# Log or print the durations
for task in task_durations:
    print(f"Task {task['task_name']} took {task['duration_seconds']} seconds")

# COMMAND ----------

# DBTITLE 1,Working - 1
import requests
import json

# Your Databricks instance and token
databricks_url = "https://adb-4661267993302765.5.azuredatabricks.net"
# token = "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"

# The run ID of the job
run_id = "1123224513083435"

# Fetch job run details using the correct endpoint
response = requests.get(
    f"{databricks_url}/api/2.0/jobs/runs/get?run_id={run_id}",
    headers={"Authorization": f"Bearer {token}"}
)

run_details = response.json()

# Print the run details to understand its structure
print(json.dumps(run_details, indent=2))

# Loop through each task in the run details and capture duration
task_durations = []
if 'tasks' in run_details:
    for task in run_details['tasks']:
        task_name = task['task_key']
        start_time = task['start_time']
        end_time = task['end_time']
        duration = task['duration'] / 1000  # Convert duration from milliseconds to seconds

        task_durations.append({
            'task_name': task_name,
            'start_time': start_time,
            'end_time': end_time,
            'duration_seconds': duration
        })

# Log or print the durations
for task in task_durations:
    print(f"Task {task['task_name']} took {task['duration_seconds']} seconds")


# COMMAND ----------

import requests
import json

# Your Databricks instance and token
databricks_url = "https://adb-4661267993302765.5.azuredatabricks.net"
# token = "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"

# Job ID and Task Run ID
job_id = "108554347653341"
task_run_id = "770856512969209"

# API endpoint for listing all job runs
url = f"{databricks_url}/api/2.0/jobs/runs/list?job_id={job_id}"

# Fetch the list of job runs
response = requests.get(url, headers={"Authorization": f"Bearer {token}"})

# Check if the response was successful
if response.status_code == 200:
    runs = response.json().get("runs", [])
    
    # Print the full response to inspect the structure
    print("Full API Response:")
    print(json.dumps(runs, indent=2))

    # Filter runs for the specific task run_id
    task_runs = [run for run in runs if str(run.get("parent_run_id")) == task_run_id]

    # Print the filtered runs for the task
    print(f"Found {len(task_runs)} task runs for task_run_id {task_run_id}:")
    for task_run in task_runs:
        print(json.dumps(task_run, indent=2))
else:
    print(f"Failed to fetch job runs: {response.status_code} - {response.text}")


# COMMAND ----------

# DBTITLE 1,Parent run (2nd task) info
import requests

# Set your Databricks URL and token
databricks_url = "https://adb-4661267993302765.5.azuredatabricks.net"
# token = "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"

# Set the run_id of the task you want logs for
run_id = "770856512969209"

# Fetch task logs
response = requests.get(
    f"{databricks_url}/api/2.0/jobs/runs/get-output?run_id={run_id}",
    headers={"Authorization": f"Bearer {token}"}
)

logs = response.json()

# Print the logs to understand its structure
print(json.dumps(logs, indent=2))


# COMMAND ----------

import requests
import json

# Define your Databricks instance URL, token, job_id, and parent_run_id
databricks_instance_url = "https://adb-4661267993302765.5.azuredatabricks.net"  # e.g., https://adb-1234567890.azuredatabricks.net
# databricks_token =  "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"
job_id = "108554347653341"  # Replace with your actual Job ID
parent_run_id = "770856512969209"  # Replace with your actual Parent Run ID

# databricks_url = "https://adb-4661267993302765.5.azuredatabricks.net"
# token = "dapi6fde62e4d8f93b609e2dcf54123f15c5-3"

# Set the API endpoint for listing task runs
api_url = f"{databricks_instance_url}/api/2.0/jobs/runs/list"

# Define the headers for the request
headers = {
    "Authorization": f"Bearer {databricks_token}",
    "Content-Type": "application/json"
}

# Define the parameters for the API request
params = {
    "job_id": job_id,
    "parent_run_id": parent_run_id  # The parent run_id of the For Each task
}

# Make the API request to get the list of runs for the given parent run
response = requests.get(api_url, headers=headers, params=params)

# Check the response status
if response.status_code == 200:
    # Parse the JSON response
    runs = response.json()

    # Check if there are runs (iterations) available
    if 'runs' in runs:
        print(f"Found {len(runs['runs'])} iterations for parent run_id {parent_run_id}:")

        # Iterate through each sub-task run and print its details
        for run in runs['runs']:
            print(json.dumps(run, indent=4))  # Pretty print the run details

    else:
        print(f"No runs found for parent_run_id: {parent_run_id}")

else:
    print(f"Failed to fetch task runs. Status code: {response.status_code}")
    print(f"Response: {response.text}")


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM system.lakeflow.job_task_run_timeline
# MAGIC  WHERE
# MAGIC     job_id = '255902689725806'
# MAGIC     AND job_run_id = '1085446949571369'

# COMMAND ----------

import requests
import json

# Your Databricks instance and token
databricks_url = "https://adb-4661267993302765.5.azuredatabricks.net"
# token = "dapid250ff92f46cf6a99971c6763def5453-3"    # created on - 2025-01-30, valid for 90 days

# The run ID of the job
run_id = "274090069644973"

# Fetch job run details using the correct endpoint
response = requests.get(
    f"{databricks_url}/api/2.0/jobs/runs/get?run_id={run_id}",
    headers={"Authorization": f"Bearer {token}"}
)

run_details = response.json()

# Print the run details to understand its structure
print(json.dumps(run_details, indent=2))

# Loop through each task in the run details and capture duration
task_durations = []
if 'tasks' in run_details:
    for task in run_details['tasks']:
        task_name = task['task_key']
        start_time = task['start_time']
        end_time = task['end_time']
        duration = task['duration'] / 1000  # Convert duration from milliseconds to seconds

        task_durations.append({
            'task_name': task_name,
            'start_time': start_time,
            'end_time': end_time,
            'duration_seconds': duration
        })

# Log or print the durations
for task in task_durations:
    print(f"Task {task['task_name']} took {task['duration_seconds']} seconds")
