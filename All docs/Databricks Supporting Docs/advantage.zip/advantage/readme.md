## Custom DABs template - minimal example
A custom template can be leveraged to ensure projects with DABs are created in a consistent manner. Some useful links:
- [Databricks documentation](https://docs.databricks.com/en/dev-tools/bundles/templates.html#create-a-custom-bundle-template) 
- [Template backing the default Databricks bundle](https://github.com/databricks/cli/tree/main/libs/template/templates/default-python)
- [Example of a very complex bundle template (MLOps Stacks)](https://github.com/databricks/mlops-stacks)


### bundle-template-example
This is an example custom bundle template.  

`databricks_template_schema.json` contains  variables used to convert the template to a bundle. When initializing a bundle from this template user is prompted for values of these variables. Alternatively, values can be specified in a config file.

`template` directory contains all files that will be created when a bundle is initialized. The default databricks bundle (second link at the top) provides an example of how to skip files based on prompts, if this is something that interests you.

`databricks_template_schema.json` and `databricks.yml.tmpl` are the minimum that is necessary to have a valid template, but this example structures files in a more common manner.

Within `databricks.yml.tmpl` you will see `{{workspace_host}}` - this is an example of a variable that is resolved when a bundle is initialized from the template.


### project-example

This is the destination where example bundle will be initialized. 

`bundle_config.json` is used to show how to supply variables with a config file. Notice that the file can contain additional properties not used in bundle initialization, like `"extra_property"`.


### How to use this

Open a terminal and move to the project example directory.
```
cd project-example
```
Make sure your databricks cli is configured with a valid profile. If it is not, follow the steps [here](https://docs.databricks.com/en/dev-tools/cli/tutorial.html).
```
databricks auth profiles
```
#### Initialize the bundle
Initialize a bundle using the config file. This example references a DABs template in local file storage, but a github repository can also be referenced.
```
databricks bundle init ../bundle-template-example --config-file bundle_config.json
```
If you want to specify variable values yourself, omit the --config-file flag
```
databricks bundle init ../bundle-template-example
```
#### That's it!
Take a look around the generated files. You can see a preview of what will be created from your bundle with
```
databricks bundle validate --output json
```

