def add_one(number):
    return number + 1

def say_hello():
    print("hello world")