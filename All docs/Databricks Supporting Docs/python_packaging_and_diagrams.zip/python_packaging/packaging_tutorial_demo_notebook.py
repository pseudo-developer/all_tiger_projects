# Databricks notebook source
# MAGIC %pip install /Workspace/Users/martina.desender@databricks.com/python_packaging_tutorial-0.0.1-py3-none-any.whl
# MAGIC %restart_python

# COMMAND ----------

from ingestion_framework import example

example.say_hello()

# COMMAND ----------

example.add_one(4)

# COMMAND ----------

from importlib.resources import files

text = files('cli.data').joinpath('sample.yaml').read_text()
text

# COMMAND ----------
import importlib
print(importlib.util.find_spec('ingestion_framework'))
print()
print(importlib.util.find_spec('cli.data'))

# COMMAND ----------
