#### How to use

##### Optional but highly recommended - create virtual environment
```
python3 -m venv venv
source venv/bin/activate
```
##### Install build
```
pip install build
```
##### Build the package
```
python -m build
```
By default, build will create two distributions in the `dist` directory: 
- source distribution (tar.gz)
- binary distribution (.whl)

Binary distribution is built from the source distribution. You can build a binary distribution directly with
```
python -m build -w  
```
Check out additional options with `python -m build -help`

Remember to include the build directories in your .gitignore file. 

##### Upload the package
Package can be uploaded to private package repository such as Azure Artifacts, or to Databricks volumes (private preview) or workspaces. See corresponding documentation.

- [Publishing to Azure Artifactory](https://learn.microsoft.com/en-us/azure/devops/artifacts/quickstarts/python-packages?view=azure-devops&tabs=twine)
- [Publish Python packages with Azure Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/artifacts/pypi?view=azure-devops&tabs=yaml)

##### Install the package on Databricks
Packages can be installed with the magic command `%pip`, with the exact syntax depending on where the package was uploaded.  
See `packaging_tutorial_demo_notebook.py` for an example of installing from a Databricks workspace.

- [Installing libraries on databricks](https://learn.microsoft.com/en-us/azure/databricks/libraries/notebooks-python-libraries)
- [Cluster libraries](https://learn.microsoft.com/en-us/azure/databricks/libraries/cluster-libraries)
- [Serverless dependecies](https://learn.microsoft.com/en-us/azure/databricks/compute/serverless/dependencies)

##### Install the package locally and try out the cli
Set up a new virtual environment as before, and run
```
pip install {path to your local wheel file}
```
In practice the package would be installed from Azure Artifacts or a similar package repository.

Try running `setup-framework` the terminal - notice the `click` dependency is missing. This is intentional, so the package is not included when the framework is installed on Databricks. Once the package is published to a package repository the additional dependency can be specified with `pip install package-name[cli]`. For now, manually install click
```
pip install click
```
Run the cli
```
setup-framework --count 2
```

#### Including data files
Data files can be included in a wheel file, but typically are not. The demo notebook shows a simple usage of reading a packaged yaml file. Please note where the file is stored: in python site packages on the local file system.

Databricks cli can reference DABs templates in git repos, not just the local file system.

#### Python packaging resources
- [Python packaging user guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
- [Setuptools quickstart](https://setuptools.pypa.io/en/latest/userguide/quickstart.html)
- [Dependencies management in setuptools](https://setuptools.pypa.io/en/latest/userguide/dependency_management.html)
- [Package discovery and namespace packages](https://setuptools.pypa.io/en/latest/userguide/package_discovery.html#)
- [Entry points](https://setuptools.pypa.io/en/latest/userguide/entry_point.html)
- [Data files support](https://setuptools.pypa.io/en/latest/userguide/datafiles.html)